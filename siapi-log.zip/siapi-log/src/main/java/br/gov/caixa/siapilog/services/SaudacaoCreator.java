package br.gov.caixa.siapilog.services;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class SaudacaoCreator {
    private Logger log = LoggerFactory.getLogger(SaudacaoCreator.class);
    public String gerarSaudacao(){
        log.info("Gerando mensagem em portugues.");
        log.debug("Transacao prestes a retornar");
        return "Ola em portugues";
    }
}