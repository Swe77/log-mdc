package br.gov.caixa.siapilog.controllers;

import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import br.gov.caixa.siapilog.services.SaudacaoCreator;


@RestController
public class HelloEndpoint {
    private Logger log = LoggerFactory.getLogger(HelloEndpoint.class);
    @Autowired
    SaudacaoCreator saudacaoPortugues;

    @GetMapping(value="api")
    public String getMethodName() {
        
        MDC.put("nomeTransacao", "Greeting");
        MDC.put("UUID", UUID.randomUUID().toString());
        log.info("Criando saudacao");

        String saudacao = saudacaoPortugues.gerarSaudacao();

        log.info("Devolvendo saudacao");
        return saudacao;
    }
    
    
}